#ifndef HABITACION_H
#define HABITACION_H
#include <iostream>
#include<fstream>
#include<stdlib.h>
#include<cstdlib>
#include<conio.h>
#include<iomanip>
#include "Menus.h"

using namespace std;

class Habitaciones
{
   void insertarHabitaciones(string nombreUsuario);

    private:
       string idHabitacion, nombreHabitacion, Habitacion;
};

#endif // RECETAS_H
